import React from 'react';

// This component is disabled and no longer used in the application.
const AiInsight: React.FC = () => {
  return null;
};

export default AiInsight;