// This service has been disabled for the static GitHub Pages deployment.
// The AI Assistant feature is no longer active.

export const generateGeospatialInsight = async (query: string): Promise<string> => {
  console.warn("AI Insight service is disabled.");
  return "Service disabled.";
};